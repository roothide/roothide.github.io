// Copyright © 2021 Apple Inc. All rights reserved.

#import <Foundation/Foundation.h>
#import <SafariServices/SFFoundation.h>

NS_ASSUME_NONNULL_BEGIN

SF_EXTERN NSString * const SFExtensionMessageKey API_AVAILABLE(ios(15.0));

NS_ASSUME_NONNULL_END
